import * as moment from 'moment';

var element:HTMLCanvasElement;
