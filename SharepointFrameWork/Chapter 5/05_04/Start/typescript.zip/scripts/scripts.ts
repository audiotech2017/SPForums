function add(a, b) {
    return a + b;
}

add(1);