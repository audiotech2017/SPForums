function add(a, b) {
    return a + b;
}
add(1);
//# sourceMappingURL=scripts.js.map